"""
翻译通用 Agent (translate-agent)

一个 agent + 可配置 task 的「AI 增强层」：站在百度机器翻译之上，用 LLM 补足
机械翻译做不到的通顺/风格化/上下文连贯。

支持三个任务（按 input.task 分发）：
- translate：百度机器翻译打底 + LLM 润色（mt_provider=baidu，默认）；或纯 LLM 翻译（mt_provider=llm）
- polish：在已有文本上做风格化润色（不改语义只改表达）
- context：带前文上下文 + 术语库的连贯翻译（解决指代/术语一致）

工程模式复用 json-repairer：
- _build_llm()：max_retries=0 + timeout，禁用 SDK 内部重试
- TOTAL_TIMEOUT + _check_timeout(stage)：agent 总超时守护
- MAX_LLM_CALLS：LLM 调用失败重试
- _normalize_llm_output()：剥离 markdown fence
- 流式：config["stream"] 为 True 时逐 token yield {"token": ...}
"""
from __future__ import annotations

import logging
import os
import time
from typing import Optional

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

# miao_runner 用 spec_from_file_location 加载本模块，不会自动把本目录加入 sys.path，
# 这里显式注入，保证同目录的 baidu_client / prompts 可被 import。
import sys as _sys
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in _sys.path:
    _sys.path.insert(0, _HERE)

from baidu_client import BaiduTranslateClient, BaiduTranslateError
from prompts import (
    build_context_prompt,
    build_polish_prompt,
    build_translate_prompt,
)

logger = logging.getLogger("translate-agent")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")

MODEL = os.environ.get("LLM_MODEL", os.environ.get("DASHSCOPE_MODEL", "qwen-plus"))
API_KEY = os.environ.get("LLM_API_KEY", os.environ.get("DASHSCOPE_API_KEY", ""))
BASE_URL = os.environ.get("LLM_BASE_URL", os.environ.get("DASHSCOPE_BASE_URL", ""))
TEMPERATURE = float(os.environ.get("LLM_TEMPERATURE", os.environ.get("DASHSCOPE_TEMPERATURE", "0.3")))
MAX_TOKENS = int(os.environ.get("LLM_MAX_TOKENS", os.environ.get("DASHSCOPE_MAX_TOKENS", "4096")))
LLM_TIMEOUT = int(os.environ.get("LLM_TIMEOUT", "120"))

# 一次调用中最多 2 次 LLM 尝试（含首次），避免级联延迟
MAX_LLM_CALLS = 2
# 单次 agent 调用总超时，必须在平台 invoke_sync_timeout 之内（默认 300s）
TOTAL_TIMEOUT = int(os.environ.get("AGENT_TOTAL_TIMEOUT", "240"))

VALID_TASKS = {"translate", "polish", "context"}

logger.info(
    "Config: model=%s, base_url=%s, temp=%s, max_tokens=%s, timeout=%ss",
    MODEL,
    BASE_URL[:30] if BASE_URL else "(empty)",
    TEMPERATURE,
    MAX_TOKENS,
    LLM_TIMEOUT,
)


# -------- LLM 构建与输出标准化（复用 json-repairer 模式）--------

def _build_llm() -> ChatOpenAI:
    """构建 LLM 实例。max_retries=0 禁用 SDK 内部重试，agent 自己重试。"""
    kwargs = dict(
        model=MODEL,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS,
        api_key=API_KEY or "sk-placeholder",
        timeout=LLM_TIMEOUT,
        max_retries=0,
    )
    if BASE_URL:
        kwargs["base_url"] = BASE_URL
    return ChatOpenAI(**kwargs)


def _strip_markdown_fence(text: str) -> str:
    """安全剥离 markdown code fence。"""
    if not text.startswith("```"):
        return text
    lines = text.split("\n")
    result_lines = lines[1:]
    while result_lines and result_lines[-1].strip() in ("```", "``"):
        result_lines.pop()
    return "\n".join(result_lines).strip()


def _normalize_llm_output(text: str) -> str:
    return _strip_markdown_fence((text or "").strip())


def _call_llm(llm: ChatOpenAI, system_prompt: str, user_content: str) -> str:
    """调用 LLM 并标准化输出，带一次重试（复用 MAX_LLM_CALLS 模式）。"""
    last_err: Optional[Exception] = None
    for attempt in range(MAX_LLM_CALLS):
        try:
            messages = [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_content),
            ]
            response = llm.invoke(messages)
            out = _normalize_llm_output(response.content)
            if out:
                return out
            last_err = ValueError("LLM 返回空响应")
        except Exception as e:  # noqa: BLE001
            last_err = e
            logger.warning("LLM call attempt %d failed: %s", attempt + 1, e)
    raise ValueError(f"LLM 调用失败（{MAX_LLM_CALLS} 次尝试）：{last_err}")


def _stream_llm(llm: ChatOpenAI, system_prompt: str, user_content: str):
    """流式调用 LLM，逐 token yield {"token": ...}。"""
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_content),
    ]
    for chunk in llm.stream(messages):
        if chunk.content:
            yield {"token": chunk.content}


# -------- 输入解析 --------

def _parse_input(input: dict) -> dict:
    task = (input.get("task") or "translate").strip().lower()
    if task not in VALID_TASKS:
        task = "translate"
    return {
        "task": task,
        "text": input.get("text", "") or "",
        "original": input.get("original", "") or "",
        "source_lang": input.get("source_lang", "auto") or "auto",
        "target_lang": input.get("target_lang", "en") or "en",
        "tone": input.get("tone"),
        "domain": input.get("domain"),
        "glossary": input.get("glossary") or [],
        "context": input.get("context", "") or "",
        "mt_provider": (input.get("mt_provider") or "baidu").strip().lower(),
    }


# -------- 各任务的 user content 构造 --------

def _translate_user_content(text: str, mt_draft: Optional[str], source_lang: str) -> str:
    if mt_draft is not None:
        return f"原文（{source_lang}）：\n{text}\n\n机器译文：\n{mt_draft}"
    return text


def _context_user_content(text: str, context: str) -> str:
    return f"前文上下文：\n{context}\n\n待翻译文本：\n{text}"


# -------- 三任务实现 --------

def _do_translate(llm: ChatOpenAI, p: dict, check_timeout) -> dict:
    """百度机器翻译打底 + LLM 润色；或纯 LLM 翻译。"""
    mt_draft: Optional[str] = None
    baidu_note = ""

    if p["mt_provider"] != "llm":
        client = BaiduTranslateClient()
        if client.configured:
            try:
                check_timeout("baidu")
                mt_draft = client.translate(
                    p["text"], p["source_lang"], p["target_lang"]
                )
            except BaiduTranslateError as e:
                # 百度失败优雅降级到纯 LLM 翻译，不崩溃
                logger.warning("Baidu translate failed, fallback to LLM: %s", e)
                baidu_note = f"百度翻译降级（{e}），已改用 LLM 直接翻译"
        else:
            baidu_note = "百度未配置密钥，已改用 LLM 直接翻译"

    check_timeout("llm_translate")
    system = build_translate_prompt(
        p["target_lang"], p["tone"], p["domain"], p["glossary"],
        has_mt_draft=mt_draft is not None,
    )
    user_content = _translate_user_content(p["text"], mt_draft, p["source_lang"])
    translated = _call_llm(llm, system, user_content)

    result = {
        "task": "translate",
        "translated": translated,
        "source_lang": p["source_lang"],
        "target_lang": p["target_lang"],
        "bilingual": [{"src": p["text"], "tgt": translated}],
    }
    if mt_draft is not None:
        result["mt_draft"] = mt_draft
    if baidu_note:
        result["notes"] = baidu_note
    return result


def _do_polish(llm: ChatOpenAI, p: dict, check_timeout) -> dict:
    """在已有文本上做风格化润色（不改语义）。"""
    check_timeout("llm_polish")
    system = build_polish_prompt(p["target_lang"], p["tone"], p["domain"], p["glossary"])
    user_content = p["text"]
    if p["original"]:
        user_content = f"原文（供参考，勿改变语义）：\n{p['original']}\n\n待润色文本：\n{p['text']}"
    polished = _call_llm(llm, system, user_content)
    return {
        "task": "polish",
        "translated": polished,
        "polished": polished,
        "notes": "已按指定风格润色，保持原语义",
    }


def _do_context(llm: ChatOpenAI, p: dict, check_timeout) -> dict:
    """带前文上下文 + 术语库的连贯翻译。"""
    check_timeout("llm_context")
    system = build_context_prompt(p["target_lang"], p["tone"], p["domain"], p["glossary"])
    user_content = _context_user_content(p["text"], p["context"])
    translated = _call_llm(llm, system, user_content)
    result = {
        "task": "context",
        "translated": translated,
        "source_lang": p["source_lang"],
        "target_lang": p["target_lang"],
        "bilingual": [{"src": p["text"], "tgt": translated}],
    }
    if p["glossary"]:
        result["glossary_applied"] = p["glossary"]
    return result


# -------- 流式路径：仅对 LLM 部分逐 token yield --------

def _stream_invoke(p: dict, llm: ChatOpenAI):
    task = p["task"]
    if task == "translate":
        mt_draft: Optional[str] = None
        if p["mt_provider"] != "llm":
            client = BaiduTranslateClient()
            if client.configured:
                try:
                    mt_draft = client.translate(
                        p["text"], p["source_lang"], p["target_lang"]
                    )
                except BaiduTranslateError as e:
                    logger.warning("Baidu translate failed (stream), fallback: %s", e)
        system = build_translate_prompt(
            p["target_lang"], p["tone"], p["domain"], p["glossary"],
            has_mt_draft=mt_draft is not None,
        )
        user_content = _translate_user_content(p["text"], mt_draft, p["source_lang"])
    elif task == "polish":
        system = build_polish_prompt(p["target_lang"], p["tone"], p["domain"], p["glossary"])
        user_content = p["text"]
        if p["original"]:
            user_content = f"原文（供参考，勿改变语义）：\n{p['original']}\n\n待润色文本：\n{p['text']}"
    else:  # context
        system = build_context_prompt(p["target_lang"], p["tone"], p["domain"], p["glossary"])
        user_content = _context_user_content(p["text"], p["context"])

    yield from _stream_llm(llm, system, user_content)


# -------- 标准入口 --------

def invoke(input: dict, config: dict = None):
    """miao-ai Agent 标准入口。

    非流式：返回 dict；流式（config["stream"]=True）：返回 generator 逐 token yield。
    """
    config = config or {}
    p = _parse_input(input)

    if not p["text"]:
        return {"task": p["task"], "translated": "", "answer": "", "notes": "输入文本为空"}

    logger.info(
        "Invoke: task=%s len=%d %s->%s mt=%s stream=%s",
        p["task"], len(p["text"]), p["source_lang"], p["target_lang"],
        p["mt_provider"], bool(config.get("stream")),
    )

    llm = _build_llm()

    # 流式模式
    if config.get("stream"):
        return _stream_invoke(p, llm)

    # 非流式模式：超时守护
    t0 = time.time()

    def _check_timeout(stage: str) -> None:
        if time.time() - t0 > TOTAL_TIMEOUT:
            raise TimeoutError(f"Agent 总超时（{TOTAL_TIMEOUT}s），阶段：{stage}")

    if p["task"] == "translate":
        result = _do_translate(llm, p, _check_timeout)
    elif p["task"] == "polish":
        result = _do_polish(llm, p, _check_timeout)
    else:
        result = _do_context(llm, p, _check_timeout)

    logger.info("Invoke done: task=%s %.2fs", p["task"], time.time() - t0)
    # 顶层 answer 便于前端 Try Run（普通模式取 output.answer）直接展示译文；
    # 流式模式仍逐 token 输出，不受影响。translated 等字段保留向后兼容。
    result["answer"] = result.get("translated", "")
    return result
