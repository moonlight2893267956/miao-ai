"""
百度翻译开放平台客户端（自包含）。

- 自管密钥：从环境变量 BAIDU_TRANSLATE_APPID / BAIDU_TRANSLATE_SECRET 读取。
- 签名算法（MD5）：sign = md5(appid + q + salt + secret)。
- 通用文本翻译 endpoint：https://fanyi-api.baidu.com/api/trans/vip/translate

百度按「字符数」计费（不同于 LLM 的 token），本模块对每次调用记录字符数日志，
预留字符级审计接口（record_usage），MVP 阶段仅打日志，不驱动前端。
"""
from __future__ import annotations

import hashlib
import logging
import os
import random
import time
from typing import Callable, Optional

import requests

logger = logging.getLogger("translate-agent.baidu")

BAIDU_ENDPOINT = os.environ.get(
    "BAIDU_TRANSLATE_ENDPOINT",
    "https://fanyi-api.baidu.com/api/trans/vip/translate",
)
BAIDU_APPID = os.environ.get("BAIDU_TRANSLATE_APPID", "")
BAIDU_SECRET = os.environ.get("BAIDU_TRANSLATE_SECRET", "")
BAIDU_TIMEOUT = int(os.environ.get("BAIDU_TRANSLATE_TIMEOUT", "10"))

# 百度错误码 → 友好中文说明（额度/授权类错误必须优雅提示，不崩溃）
BAIDU_ERROR_MESSAGES = {
    "52001": "百度翻译请求超时，请重试",
    "52002": "百度翻译系统错误，请重试",
    "52003": "百度翻译未授权：appid 无效或未开通服务",
    "54000": "百度翻译必填参数为空",
    "54001": "百度翻译签名错误（请检查 appid/secret）",
    "54003": "百度翻译访问频率受限，请降低调用频率",
    "54004": "百度翻译账户余额不足",
    "54005": "长 query 请求频繁，请稍后再试",
    "58000": "百度翻译客户端 IP 非法",
    "58001": "百度翻译不支持的语种方向",
    "58002": "百度翻译服务当前已关闭",
    "90107": "百度翻译认证未通过或未生效",
}


class BaiduTranslateError(RuntimeError):
    """百度翻译调用失败（网络/签名/额度等），带上错误码便于上层降级。"""

    def __init__(self, message: str, code: Optional[str] = None):
        super().__init__(message)
        self.code = code


def _make_sign(appid: str, query: str, salt: str, secret: str) -> str:
    """MD5 签名：md5(appid + q + salt + secret)。"""
    raw = f"{appid}{query}{salt}{secret}"
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


class BaiduTranslateClient:
    """百度通用文本翻译客户端。"""

    def __init__(
        self,
        appid: Optional[str] = None,
        secret: Optional[str] = None,
        endpoint: str = BAIDU_ENDPOINT,
        timeout: int = BAIDU_TIMEOUT,
        usage_recorder: Optional[Callable[[int, str, str], None]] = None,
    ):
        self.appid = appid or BAIDU_APPID
        self.secret = secret or BAIDU_SECRET
        self.endpoint = endpoint
        self.timeout = timeout
        # 预留字符级审计接口：MVP 默认 _log_usage，仅打日志
        self.usage_recorder = usage_recorder or self._log_usage

    @property
    def configured(self) -> bool:
        """是否已配置密钥（未配置时上层应降级到纯 LLM 翻译）。"""
        return bool(self.appid and self.secret)

    def _log_usage(self, char_count: int, source_lang: str, target_lang: str) -> None:
        logger.info(
            "baidu usage: chars=%d %s->%s", char_count, source_lang, target_lang
        )

    def translate(
        self,
        text: str,
        source_lang: str = "auto",
        target_lang: str = "en",
    ) -> str:
        """调用百度翻译，返回拼接后的译文。

        Raises:
            BaiduTranslateError: 未配置密钥、网络错误或百度返回错误码时。
        """
        if not self.configured:
            raise BaiduTranslateError(
                "百度翻译未配置：请设置 BAIDU_TRANSLATE_APPID / BAIDU_TRANSLATE_SECRET",
                code="unconfigured",
            )
        if not text:
            return ""

        salt = str(random.randint(10_000_000_000, 99_999_999_999))
        sign = _make_sign(self.appid, text, salt, self.secret)
        payload = {
            "q": text,
            "from": source_lang or "auto",
            "to": target_lang,
            "appid": self.appid,
            "salt": salt,
            "sign": sign,
        }

        t0 = time.time()
        try:
            resp = requests.post(self.endpoint, data=payload, timeout=self.timeout)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise BaiduTranslateError(f"百度翻译网络错误：{e}", code="network") from e
        except ValueError as e:
            raise BaiduTranslateError(f"百度翻译响应解析失败：{e}", code="decode") from e

        if "error_code" in data:
            code = str(data.get("error_code"))
            friendly = BAIDU_ERROR_MESSAGES.get(
                code, f"百度翻译错误（code={code}）：{data.get('error_msg', '')}"
            )
            raise BaiduTranslateError(friendly, code=code)

        results = data.get("trans_result", [])
        translated = "\n".join(item.get("dst", "") for item in results)

        # 字符级审计（预留接口，MVP 仅日志）
        try:
            self.usage_recorder(len(text), source_lang, target_lang)
        except Exception:  # 审计失败不影响主流程
            logger.warning("usage_recorder failed", exc_info=True)

        logger.info(
            "baidu translate ok: %s->%s chars=%d %.2fs",
            source_lang,
            target_lang,
            len(text),
            time.time() - t0,
        )
        return translated
