"""
翻译通用 agent 的三任务 system prompt 与动态指令拼装。

设计原则：
- 每个任务一个基础 system prompt，语言/风格/领域/术语库等作为「指令片段」动态拼接。
- 强制模型只输出目标文本本身，不带解释、不带 markdown fence（由 agent 侧再做剥离兜底）。
"""
from __future__ import annotations

from typing import List, Optional

# 语种代码 → 可读名称（用于 prompt 表述，非穷举，未知则原样透传）
LANG_NAMES = {
    "auto": "自动识别",
    "zh": "中文",
    "en": "英语",
    "jp": "日语",
    "ja": "日语",
    "kor": "韩语",
    "ko": "韩语",
    "fra": "法语",
    "fr": "法语",
    "de": "德语",
    "spa": "西班牙语",
    "es": "西班牙语",
    "ru": "俄语",
    "th": "泰语",
    "vie": "越南语",
    "ara": "阿拉伯语",
}

# tone / domain 的可读表述
TONE_HINTS = {
    "formal": "正式、书面",
    "casual": "口语、轻松自然",
    "business": "商务、专业得体",
    "marketing": "营销、有吸引力的表达（突出卖点、号召力）",
    "literary": "文学、优美流畅",
    "academic": "学术、严谨精确",
}

DOMAIN_HINTS = {
    "tech": "技术/软件领域，保留专有名词与代码标识符不译",
    "medical": "医疗领域，术语需准确规范",
    "legal": "法律领域，措辞需严谨、无歧义",
    "finance": "金融领域，数字与术语需准确",
}


def lang_name(code: Optional[str]) -> str:
    if not code:
        return "目标语言"
    return LANG_NAMES.get(code, code)


def _style_directives(tone: Optional[str], domain: Optional[str]) -> str:
    parts: List[str] = []
    if tone:
        parts.append(f"- 语气风格：{TONE_HINTS.get(tone, tone)}")
    if domain:
        parts.append(f"- 领域约束：{DOMAIN_HINTS.get(domain, domain)}")
    return "\n".join(parts)


def _glossary_directives(glossary: Optional[List[dict]]) -> str:
    if not glossary:
        return ""
    lines = ["以下术语必须严格按对照表翻译（左=原文，右=指定译法）："]
    for pair in glossary:
        src = pair.get("src", "")
        tgt = pair.get("tgt", "")
        if src and tgt:
            lines.append(f"- {src} → {tgt}")
    return "\n".join(lines)


# -------- translate：机器译文润色 / 纯 LLM 翻译 --------

TRANSLATE_SYSTEM = """你是一名专业翻译专家。你的任务是把用户给出的文本翻译成 {target} 并保证地道、通顺、忠实原意。

要求：
- 忠实传达原文含义，不增删信息
- 译文符合 {target} 的表达习惯，避免翻译腔
- 保留原文的段落与换行结构
- 只输出译文本身，不要任何解释、不要 markdown 代码块"""

TRANSLATE_POLISH_SYSTEM = """你是一名专业翻译润色专家。下面给出「原文」与一份「机器译文」。请在忠实于原文的前提下，把机器译文改写得更地道、通顺、自然。

要求：
- 以原文语义为准，修正机器译文的生硬、错译、漏译
- 译文符合 {target} 的表达习惯
- 保留段落与换行结构
- 只输出润色后的最终译文，不要解释、不要 markdown 代码块"""


# -------- polish：在已有译文上做风格化润色（不改语义只改表达） --------

POLISH_SYSTEM = """你是一名文字润色专家。请对给定文本进行润色，使其更通顺、更符合目标风格，但不得改变原有语义。

要求：
- 不增删核心信息，只优化表达
- 只输出润色后的文本，不要解释、不要 markdown 代码块"""


# -------- context：带上下文的连贯翻译（术语一致 / 指代消解） --------

CONTEXT_SYSTEM = """你是一名专业翻译专家，擅长长文档与对话的连贯翻译。下面给出「前文上下文」与「待翻译文本」。请把待翻译文本翻译成 {target}，并与上下文保持连贯。

要求：
- 保持术语、人名、代词指代在全文的一致性
- 参考上下文消解歧义（如 it/they 指代什么）
- 只翻译「待翻译文本」，不要翻译或复述上下文
- 只输出译文本身，不要解释、不要 markdown 代码块"""


def build_translate_prompt(
    target_lang: Optional[str],
    tone: Optional[str],
    domain: Optional[str],
    glossary: Optional[List[dict]],
    has_mt_draft: bool,
) -> str:
    """构造 translate 任务的 system prompt。

    has_mt_draft=True 表示已有百度机器译文，走「润色」路径；否则纯 LLM 翻译。
    """
    base = (TRANSLATE_POLISH_SYSTEM if has_mt_draft else TRANSLATE_SYSTEM).format(
        target=lang_name(target_lang)
    )
    extra = "\n".join(filter(None, [_style_directives(tone, domain), _glossary_directives(glossary)]))
    return f"{base}\n\n{extra}" if extra else base


def build_polish_prompt(
    target_lang: Optional[str],
    tone: Optional[str],
    domain: Optional[str],
    glossary: Optional[List[dict]],
) -> str:
    extra_parts = []
    if target_lang and target_lang != "auto":
        extra_parts.append(f"- 目标语言：{lang_name(target_lang)}")
    extra_parts.append(_style_directives(tone, domain))
    extra_parts.append(_glossary_directives(glossary))
    extra = "\n".join(filter(None, extra_parts))
    return f"{POLISH_SYSTEM}\n\n{extra}" if extra else POLISH_SYSTEM


def build_context_prompt(
    target_lang: Optional[str],
    tone: Optional[str],
    domain: Optional[str],
    glossary: Optional[List[dict]],
) -> str:
    base = CONTEXT_SYSTEM.format(target=lang_name(target_lang))
    extra = "\n".join(filter(None, [_style_directives(tone, domain), _glossary_directives(glossary)]))
    return f"{base}\n\n{extra}" if extra else base
